#ifndef FILLED_RECTANGLE_H
#define FILLED_RECTANGLE_H

#include "windows.h"

class filled_rectangle
{
public:
    filled_rectangle();
    ~filled_rectangle();

};

#endif // FILLED_RECTANGLE_H
