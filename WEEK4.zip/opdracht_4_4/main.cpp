#include "hwlib.hpp"
#include <stdio.h>

void add_del(hwlib::port_out & leds, auto & add, auto & del){
    int count = 0;
    while(1){
        if(del.get() && count > 0){
            count--;
            hwlib::wait_ms(200);
            
        }
        if(add.get() && count < 4){
            count++;
            hwlib::wait_ms(200);
        }
        for(int i = 0; i < count; i++){
            leds.set(0x01 << i);
            hwlib::wait_ms(5);
        }
    }
}

int main( void ){
    // kill the watchdog
    WDT->WDT_MR = WDT_MR_WDDIS;
   
    auto led0 = hwlib::target::pin_out( 2, 28 );
    auto led1 = hwlib::target::pin_out( 2, 26 );
    auto led2 = hwlib::target::pin_out( 2, 25 );
    auto led3 = hwlib::target::pin_out( 2, 24 );
    
    auto add = hwlib::target::pin_in( 3, 7);
    auto del = hwlib::target::pin_in( 3, 8);
    
    auto leds = hwlib::port_out_from_pins(led0,led1,led2,led3);

    
    add_del(leds, add, del);
}
